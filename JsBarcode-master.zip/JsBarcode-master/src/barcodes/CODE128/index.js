import CODE128 from './CODE128_AUTO.js';
import CODE128A from './CODE128A.js';
import CODE128B from './CODE128B.js';
import CODE128C from './CODE128C.js';

export {CODE128, CODE128A, CODE128B, CODE128C};
